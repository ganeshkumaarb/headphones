package com.example.volblock

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val enable = Button(this).apply {
            text = "1. Enable service in Accessibility settings"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val all = Switch(this).apply {
            text = "Block ALL volume keys while headphones plugged in (fallback)"
            isChecked = Prefs.of(context).getBoolean("block_all", false)
            setOnCheckedChangeListener { _, on ->
                Prefs.of(context).edit().putBoolean("block_all", on).apply()
            }
        }

        info = TextView(this).apply { setPadding(0, pad, 0, 0) }

        root.addView(enable); root.addView(all); root.addView(info)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val dev = Prefs.of(this).getString("last_dev", "none yet")
        info.text = "Last volume key came from input device:\n$dev"
    }
}
