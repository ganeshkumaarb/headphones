package com.example.volblock

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.view.InputDevice
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class VolumeBlockerService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode != KeyEvent.KEYCODE_VOLUME_UP &&
            event.keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) return false

        val devName = InputDevice.getDevice(event.deviceId)?.name ?: "unknown"
        Prefs.of(this).edit().putString("last_dev", devName).apply()

        if (!headsetPlugged()) return false

        val blockAll = Prefs.of(this).getBoolean("block_all", false)
        val fromHeadset = devName.contains("headset", true) ||
                devName.contains("jack", true) ||
                devName.contains("h2w", true)

        // true = consume the key (down AND up), system never sees it
        return blockAll || fromHeadset
    }

    private fun headsetPlugged(): Boolean {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
            it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }
    }
}

object Prefs {
    fun of(c: Context) = c.getSharedPreferences("volblock", Context.MODE_PRIVATE)
}
